package com.spring.bioMedical.Controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

@ControllerAdvice
class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class) // Catching any general exception
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // Return 500 status
    public String handleException(Exception e, Model model) {
        model.addAttribute("errorMessage", e.getMessage()); // Add exception message
        model.addAttribute("errorCode", HttpStatus.INTERNAL_SERVER_ERROR.value()); // Add status code
        return "error"; // Return the 'error.html' page
    }
}
